<?php



class AttachmentReq extends BaseAttachmentReq
{
	public static function model($className=__CLASS__) {
		return parent::model($className);
	}
}