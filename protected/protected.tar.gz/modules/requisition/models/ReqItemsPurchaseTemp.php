<?php



class ReqItemsPurchaseTemp extends BaseReqItemsPurchaseTemp
{
	public static function model($className=__CLASS__) {
		return parent::model($className);
	}
}