<?php



class Facility extends BaseFacility
{
	public static function model($className=__CLASS__) {
		return parent::model($className);
	}
}