<?php



class ReqOrder extends BaseReqOrder
{
	public static function model($className=__CLASS__) {
		return parent::model($className);
	}
}