<?php

/**
 * This is the model class for table "hr_employee_personal".
 *
 * The followings are the available columns in table 'hr_employee_personal':
 * @property integer $id
 * @property integer $emp_id
 * @property string $birthdate
 * @property string $gender
 * @property string $marital_status
 * @property string $SSN
 * @property string $number
 * @property string $building
 * @property string $street
 * @property integer $zip_code
 * @property string $telephone
 * @property string $cellphone
 * @property string $email
 * @property integer $is_approved
 * @property string $timestamp
 *
 * The followings are the available model relations:
 * @property HrEmployee $emp
 */
class EmployeePersonalInfo extends CActiveRecord
{
	
  public $dob_month, $dob_day, $dob_year;
  
  public function beforeSave(){
    return parent::beforeSave();
  }
  
  public static function getInfo($model_employee){
    if($model_employee->active_personal_id){ // means there is already an approved profile
      //Yii::log('1','error','app');
      return self::model()->findByPk($model_employee->active_personal_id);    
    }else{ //return the most recent profile
      //Yii::log('0','error','app');
      return self::model()->find(array(
        'condition'=>"emp_id = '$model_employee->emp_id'",
        'order'=>'timestamp desc'
      )); 
    } 
  }
  
  public function afterFind(){
    $this->decodeDOB();
    //$this->birthdate = date(Yii::app()->params['dateFormat'],strtotime($this->birthdate));
  }
                
  public function beforeValidate(){
    $this->encodeDOB();
    return parent::beforeValidate();
  }
  
  public function encodeDOB(){
    $this->birthdate = "$this->dob_year-$this->dob_month-$this->dob_day";      
  }
  
  private function decodeDOB(){
    $dob = date('Y-m-d',strtotime($this->birthdate));
    $dob = explode('-',$dob);
    $this->dob_year = $dob[0];
    $this->dob_month = $dob[1];
    $this->dob_day = $dob[2];
  }
  
  /**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return EmployeePersonalInfo the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'hr_employee_personal';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('birthdate, SSN, street, zip_code, city, state, telephone, dob_month, dob_day, dob_year', 'required'),
      array('emp_id, zip_code, is_approved', 'numerical', 'integerOnly'=>true),
			array('gender', 'length', 'max'=>8),
      array('SSN','validateLength'),
      array('SSN','numerical'),
      array('email', 'email'),
			array('marital_status, number', 'length', 'max'=>16),
			array('SSN, building, street, telephone, cellphone, email', 'length', 'max'=>128),
			array('timestamp,dob_month,dob_day,dob_year', 'safe'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, emp_id, birthdate, gender, marital_status, SSN, number, building, street, zip_code, telephone, cellphone, email, is_approved, timestamp', 'safe', 'on'=>'search'),
		);
	}

  public function validateLength(){
    if(strlen($this->SSN) != 9){
      $this->addError('SSN','SSN must be 9 digits.');
    }
  }

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'emp' => array(self::BELONGS_TO, 'HrEmployee', 'emp_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'emp_id' => 'Emp',
			'birthdate' => 'Birthdate',
			'gender' => 'Gender',
			'marital_status' => 'Marital Status',
			'SSN' => 'Social Security #',
			'number' => 'Number',
			'building' => 'Building',
			'street' => 'Street',
      'city' => 'City',
      'state' => 'State',
			'zip_code' => 'Zip Code',
			'telephone' => 'Telephone',
			'cellphone' => 'Cellphone',
			'email' => 'Email',
			'is_approved' => 'Approved Profile?',
			'timestamp' => 'Last Updated',
      'dob_month' => 'Month',
      'dob_day' => 'Day',
      'dob_year' => 'Year',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('emp_id',$this->emp_id);
		$criteria->compare('birthdate',$this->birthdate,true);
		$criteria->compare('gender',$this->gender,true);
		$criteria->compare('marital_status',$this->marital_status,true);
		$criteria->compare('SSN',$this->SSN,true);
		$criteria->compare('number',$this->number,true);
		$criteria->compare('building',$this->building,true);
		$criteria->compare('street',$this->street,true);
		$criteria->compare('zip_code',$this->zip_code);
		$criteria->compare('telephone',$this->telephone,true);
		$criteria->compare('cellphone',$this->cellphone,true);
		$criteria->compare('email',$this->email,true);
		$criteria->compare('is_approved',$this->is_approved);
		$criteria->compare('timestamp',$this->timestamp,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}